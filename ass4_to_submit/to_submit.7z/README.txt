The programm consist from 3 parts.
1.loader.py
2.utility.py
3.main.py
To run the programm use
python main.py in the command line
The graphs are not closing themselves and required pressing the x button.
The script saves nn.sol and hs.sol to the corresponding files