	Outputs the decision tree in json format.
File:
	assign1-2.py
Data:
	hepatitis-test
	hepatitis-training
Example of run:
	python assign1-2.py hepatitis-training-run-1 hepatitis-test-run-2
