Assignment 1 part 1
1.

Files: `	
Script:		assign-1-1.py
Data test:		wine-test
Data training:	wine-training

The programm is running from command line as:
	python assign-1-1.py wine-test wine-training
It can take anoter one parameter - number of k
It will is not validateing  input k, but k should be an odd number (1,3,5,7 etc)

2. 
Files: `	
Script:			assign-1-1.py
Data test:		wine-test
Data training:		wine-training



The programm is running from command line as:
	python assign-1-1.py wine-test
	python assign-1-1.py wine-training

It can take anoter one parameter - number of clusters - k
	python assign-1-1.py wine-training 5
	python assign-1-1.py wine-training 6
	python assign-1-1.py wine-test 7