Script:
 a3Part2.py

Takes 2 files - training and test from command line. 


If second file in unlablled:
Takes line by line instances from test set and print predicts label :SPAM or NON SPAM
Example1:
assignment3>python a3Part2.py spamLabelled.dat spamUnlabelled.dat

If second file is labelled:
Takes line by line instances from test set and predicts label: SPAM or NON SPAM. Shows the real class.
And calculates total accuracy.
Example2:
assignment3>python a3Part2.py crosfoldtraining.dat crosfoldtest.dat










