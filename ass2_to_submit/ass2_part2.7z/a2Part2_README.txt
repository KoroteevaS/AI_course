The assignment part 2 represented by
a2Part2.py

********************
HOW TO RUN
*********************

python a2Part2.py
----------------------

